package com.android.test.gestureapplication

import android.annotation.SuppressLint
import android.util.Log
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.round
import androidx.compose.ui.unit.toIntRect
import com.android.test.gestureapplication.state.GameState
import com.android.test.gestureapplication.state.GameUiEvent

@Composable
fun GameScreenSolutionNew(
    uiState: GameState,
    uiEvent: (GameUiEvent) -> Unit
) {

    val state = rememberLazyGridState()
    val listWithIndexes = uiState.items.withIndex()

    val selectedIdSet = rememberSaveable {
        mutableStateOf(emptySet<Int>())
    }

    fun LazyGridState.gridItemKeyAtPosition(hitPoint: Offset): Int? =
        layoutInfo.visibleItemsInfo.find { itemInfo ->
            itemInfo.size.toIntRect().contains(hitPoint.round() - itemInfo.offset)
        }?.key as? Int


    var initialKey: Int? = null
    var currentKey: Int? = null

    LazyVerticalGrid(
        state = state,
        columns = GridCells.Fixed(3),
        modifier = Modifier.pointerInput(Unit) {

            fun LazyGridState.gridItemKeyAtPosition(hitPoint: Offset): Int? =
                layoutInfo.visibleItemsInfo.find { itemInfo ->
                    itemInfo.size.toIntRect().contains(hitPoint.round() - itemInfo.offset)
                }?.key as? Int

            detectDragGesturesAfterLongPress(
                onDragStart = { offset ->
                    state.gridItemKeyAtPosition(offset)?.let { key ->
                        if (!selectedIdSet.value.contains(key)) {
                            initialKey = key
                            currentKey = key
                            selectedIdSet.value += key
                        }
                    }
                },
                onDrag = { change, dragAmount ->
                    if (initialKey != null) {
                        state.gridItemKeyAtPosition(change.position)?.let { key ->
                            if (currentKey != key) {
                                selectedIdSet.value = selectedIdSet.value
                                    .minus(initialKey!!..currentKey!!)
                                    .minus(currentKey!!..initialKey!!)
                                    .plus(initialKey!!..key)
                                    .plus(key..initialKey!!)
                                currentKey = key

                            }
                        }
                    }
                },
                onDragCancel = {
                    initialKey = null
                },
                onDragEnd = {
                    initialKey = null
                }
            )
        },
        verticalArrangement = Arrangement.spacedBy(1.dp)
    ) {
        itemsIndexed(
            items = uiState.items,
            key = { index, item -> "${index}_${item.hashCode()}" }) { index, item ->
            LetterItem(
                modifier = Modifier,
//                    .clickable {
//                    uiEvent(GameUiEvent.OnCharSelected(index))
//                    selectedIdSet.value = if (!item.isSelected) {
//                        selectedIdSet.value.plus(index)
//                    } else {
//                        selectedIdSet.value.minus(index)
//                    }
//                    Log.e("SELECTED ITEMS SET", "${selectedIdSet.value}")
//                },
                item = item,
                isSelected = item.isSelected
            )
        }
    }
}


//fun Modifier.charactersDragHandler(
//    lazyGridState: LazyGridState,
//    selectedIdSet: MutableState<Set<Int>>
//): Modifier {

//    return pointerInput(Unit) {
//
//        fun LazyGridState.gridItemKeyAtPosition(hitPoint: Offset): Int? =
//            layoutInfo.visibleItemsInfo.find { itemInfo ->
//                itemInfo.size.toIntRect().contains(hitPoint.round() - itemInfo.offset)
//            }?.key as? Int
//
//
//        var initialKey: Int? = null
//        var currentKey: Int? = null
//
//        detectDragGesturesAfterLongPress(
//            onDragStart = { offset ->
//                lazyGridState.gridItemKeyAtPosition(offset)?.let { key ->
//                    if (!selectedIdSet.value.contains(key)) {
//                        initialKey = key
//                        currentKey = key
//                        selectedIdSet.value += key
//                    }
//                }
//            },
//            onDrag = { change, dragAmount ->
//                if (initialKey != null) {
//                    lazyGridState.gridItemKeyAtPosition(change.position)?.let { key ->
//                        if (currentKey != key) {
//                            selectedIdSet.value = selectedIdSet.value
//                                .minus(initialKey!!..currentKey!!)
//                                .minus(currentKey!!..initialKey!!)
//                                .plus(initialKey!!..key)
//                                .plus(key..initialKey!!)
//                            currentKey = key
//
//                        }
//                    }
//                }
//            },
//            onDragCancel = {
//                initialKey = null
//            },
//            onDragEnd = {
//                initialKey = null
//            }
//        )
//    }
//}